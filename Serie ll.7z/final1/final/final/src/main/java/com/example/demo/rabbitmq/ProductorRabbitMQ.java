package com.example.demo.rabbitmq;

import com.example.demo.model.Turno;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ProductorRabbitMQ {

    private final RabbitTemplate rabbitTemplate;

    @Value("${rabbitmq.exchange}")
    private String exchange;

    @Value("${rabbitmq.routingkey}")
    private String routingKey;

    public ProductorRabbitMQ(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    public void enviarTurno(Turno turno) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            String mensajeJson = mapper.writeValueAsString(turno);
            rabbitTemplate.convertAndSend(exchange, routingKey, mensajeJson);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}



