package com.example.demo.datastructures;

import java.util.ArrayList;
import java.util.List;

public class ArbolServicios {

    public static class NodoServicio {
        private String nombre;
        private List<NodoServicio> hijos;

        public NodoServicio(String nombre) {
            this.nombre = nombre;
            this.hijos = new ArrayList<>();
        }

        public void agregarHijo(NodoServicio hijo) {
            hijos.add(hijo);
        }

        public String getNombre() {
            return nombre;
        }

        public List<NodoServicio> getHijos() {
            return hijos;
        }
    }

    private NodoServicio raiz;

    public ArbolServicios(String nombreRaiz) {
        this.raiz = new NodoServicio(nombreRaiz);
    }

    public NodoServicio getRaiz() {
        return raiz;
    }

    // Método recursivo para imprimir
    public void imprimir(NodoServicio nodo, String prefijo) {
        System.out.println(prefijo + nodo.getNombre());
        for (NodoServicio hijo : nodo.getHijos()) {
            imprimir(hijo, prefijo + "  ");
        }
    }
}

