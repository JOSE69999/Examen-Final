package com.example.demo.rabbitmq;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

public class ClienteConsumer {
    @RabbitListener(queues = "cola_turnos")
    public void recibirMensaje(String mensaje) {
        System.out.println("Mensaje recibido: " + mensaje);
        // Aquí puedes hacer más cosas como registrar logs, guardar en base de datos, etc.
    }
}

