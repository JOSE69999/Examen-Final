package com.example.demo.datastructures;

import java.util.LinkedList;
import java.util.List;


public class ListaHistorial<T> {

    private List<T> historial = new LinkedList<>();

    public void agregar(T elemento) {
        historial.add(elemento);
    }

    public List<T> obtenerTodos() {
        return historial;
    }
}