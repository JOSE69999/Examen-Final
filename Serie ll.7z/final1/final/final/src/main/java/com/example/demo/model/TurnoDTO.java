package com.example.demo.model;

public class TurnoDTO {

    private String servicio;
    private String cliente;

    public String getServicio() {
        return servicio;
    }

    public void setServicio(String servicio) {
        this.servicio = servicio;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    @Override
    public String toString() {
        return "TurnoDTO{" +
                "servicio='" + servicio + '\'' +
                ", cliente='" + cliente + '\'' +
                '}';
    }
}

