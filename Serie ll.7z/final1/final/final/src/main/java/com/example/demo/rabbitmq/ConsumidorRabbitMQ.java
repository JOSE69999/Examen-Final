package com.example.demo.rabbitmq;


import com.example.demo.model.Turno;
import com.example.demo.repository.TurnoRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ConsumidorRabbitMQ {

    @Autowired
    private TurnoRepository turnoRepository;  // Define este repo para Turno

    @RabbitListener(queues = "${rabbitmq.queue}")
    public void recibirMensaje(String mensajeJson) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            Turno turno = mapper.readValue(mensajeJson, Turno.class);
            System.out.println("🟢 Turno recibido: " + turno);

            turnoRepository.save(turno); // guardas en BD

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
