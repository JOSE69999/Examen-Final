package com.example.demo.controller;

import com.example.demo.model.Servicio;
import com.example.demo.model.ServicioDTO;
import com.example.demo.repository.ServicioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/servicios")
public class ServicioController {

    @Autowired
    private ServicioRepository servicioRepo;

    /** Crear servicio a partir de ServicioDTO **/
    @PostMapping
    public Servicio crearServicio(@RequestBody ServicioDTO dto) {
        System.out.println("DTO recibido (Servicio): " + dto);
        Servicio s = new Servicio();
        s.setDescripcion(dto.getDescripcion());
        s.setPrecio(dto.getPrecio());
        return servicioRepo.save(s);
    }

    /** Listar todos los servicios **/
    @GetMapping
    public List<Servicio> listarServicios() {
        return servicioRepo.findAll();
    }

    /** Obtener servicio por ID **/
    @GetMapping("/{id}")
    public ResponseEntity<Servicio> obtenerServicio(@PathVariable Long id) {
        return servicioRepo.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}