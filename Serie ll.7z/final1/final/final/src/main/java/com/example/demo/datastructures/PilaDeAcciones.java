package com.example.demo.datastructures;

import java.util.Stack;

public class PilaDeAcciones<T> {
    private Stack<T> pila;

    public PilaDeAcciones() {
        pila = new Stack<>();
    }

    // Agrega una acción a la pila
    public void push(T accion) {
        pila.push(accion);
    }

    // Deshace la última acción y la devuelve
    public T pop() {
        if (!pila.isEmpty()) {
            return pila.pop();
        }
        return null; // o lanzar excepción según prefieras
    }

    // Verifica si la pila está vacía
    public boolean estaVacia() {
        return pila.isEmpty();
    }

    // Mira la última acción sin sacarla
    public T peek() {
        if (!pila.isEmpty()) {
            return pila.peek();
        }
        return null;
    }
}

