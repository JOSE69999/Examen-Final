package com.example.demo.controller;

import com.example.demo.model.Turno;
import com.example.demo.service.TurnoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/turnos")

public class TurnoController {


    @Autowired
    private TurnoService turnoService;

    @PostMapping("/crear")
    public ResponseEntity<Turno> crearTurno(@RequestBody Turno turnoRequest) {
        Turno nuevoTurno = turnoService.crearTurno(turnoRequest.getServicio(), turnoRequest.getCliente());
        return ResponseEntity.ok(nuevoTurno);
    }

    @PostMapping("/atender")
    public ResponseEntity<Turno> atenderTurno() {
        Turno turnoAtendido = turnoService.atenderTurno();
        if (turnoAtendido == null) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(turnoAtendido);
    }

    @PostMapping("/cancelar/{id}")
    public ResponseEntity<String> cancelarTurno(@PathVariable String id) {
        boolean cancelado = turnoService.cancelarTurno(id);
        if (cancelado) {
            return ResponseEntity.ok("Turno cancelado: " + id);
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/historial")
    public ResponseEntity<?> obtenerHistorial() {
        return ResponseEntity.ok(turnoService.obtenerHistorial());
    }
}
