package com.example.demo.service;

import com.example.demo.model.Turno;
import com.example.demo.rabbitmq.ProductorRabbitMQ;
import com.example.demo.repository.TurnoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class TurnoService {

    @Autowired
    private TurnoRepository turnoRepository;

    @Autowired
    private ProductorRabbitMQ productorRabbitMQ;

    public Turno crearTurno(String servicio, String cliente) {
        Turno turno = new Turno();
        turno.setId(UUID.randomUUID().toString());
        turno.setServicio(servicio);
        turno.setCliente(cliente);
        turno.setEstado("PENDIENTE");

        turnoRepository.save(turno);
        productorRabbitMQ.enviarTurno(turno);
        return turno;
    }

    public Turno atenderTurno() {
        // Buscar el turno pendiente más antiguo (puedes cambiar lógica si quieres)
        List<Turno> pendientes = turnoRepository.findAll();
        Optional<Turno> turnoOpt = pendientes.stream()
                .filter(t -> "PENDIENTE".equals(t.getEstado()))
                .findFirst();

        if (turnoOpt.isEmpty()) return null;

        Turno turno = turnoOpt.get();
        turno.setEstado("ATENDIDO");
        turnoRepository.save(turno);
        return turno;
    }

    public boolean cancelarTurno(String id) {
        Optional<Turno> turnoOpt = turnoRepository.findById(id);
        if (turnoOpt.isPresent()) {
            Turno turno = turnoOpt.get();
            if ("PENDIENTE".equals(turno.getEstado())) {
                turno.setEstado("CANCELADO");
                turnoRepository.save(turno);
                return true;
            }
        }
        return false;
    }

    public List<Turno> obtenerHistorial() {
        // Por ejemplo devolver todos los turnos atendidos o cancelados
        return turnoRepository.findAll().stream()
                .filter(t -> !"PENDIENTE".equals(t.getEstado()))
                .toList();
    }
}