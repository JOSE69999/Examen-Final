package com.example.demo.datastructures;

import java.util.LinkedList;
import java.util.function.Predicate;

public class ColaDeTurnos<T> {
    private LinkedList<T> elementos = new LinkedList<>();

    public void encolar(T elemento) {
        elementos.addLast(elemento);
    }

    public T desencolar() {
        return elementos.pollFirst();
    }

    public boolean estaVacia() {
        return elementos.isEmpty();
    }

    public boolean eliminar(Predicate<T> condicion) {
        return elementos.removeIf(condicion);
    }
}
