package serie1.controller;

import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import serie1.model.SudokuBoard;
import serie1.service.SudokuService;

@Path("/sudoku")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)

public class SudokuResource {


    @Inject
    SudokuService sudokuService;

    @POST
    @Path("/validate")
    public Response validateBoard(SudokuBoard sudokuBoard) {
        if (sudokuBoard == null || sudokuBoard.getBoard() == null) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("{\"error\": \"Invalid or missing board.\"}")
                    .build();
        }

        boolean valid = sudokuService.isValid(sudokuBoard.getBoard());
        return Response.ok("{\"valid\":" + valid + "}").build();
    }
}

